const express = require('express');
const router = express.Router();
const productController = require('../controllers/productController');

router.get('/stats', productController.getProductStats);
router.get('/filter', productController.filterProducts);
router.get('/search', productController.searchProducts);
router.get('/avg-prices', productController.getAveragePrices);
router.get('/', productController.getAllProducts);

module.exports = router;
