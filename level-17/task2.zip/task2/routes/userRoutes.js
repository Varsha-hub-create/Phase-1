const express = require('express');
const router = express.Router();
const User = require('../models/User');

// Route: GET /user/schema
// Description: Return simplified User schema structure
router.get('/schema', (req, res) => {
    const schemaFields = {};
    for (let key in User.schema.paths) {
        if (User.schema.paths.hasOwnProperty(key)) {
            schemaFields[key] = User.schema.paths[key].instance;
        }
    }
    res.json(schemaFields);
});

// Route: POST /user
// Description: Create a new user
router.post('/', async (req, res) => {
    try {
        const { name, email, age } = req.body;
        const newUser = new User({ name, email, age });
        const savedUser = await newUser.save();
        res.status(201).json(savedUser);
    } catch (error) {
        res.status(400).json({ error: error.message });
    }
});

// Route: GET /user
// Description: Get all users
router.get('/', async (req, res) => {
    try {
        const users = await User.find();
        res.json(users);
    } catch (error) {
        res.status(500).json({ error: 'Failed to fetch users' });
    }
});

module.exports = router;
