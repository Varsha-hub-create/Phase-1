const express = require('express');
const router = express.Router();
const Post = require('../models/Post');
const User = require('../models/User');

// Create a new post
router.post('/', async (req, res) => {
  try {
    const { title, content, author } = req.body;

    // Check if author (user) exists
    const user = await User.findById(author);
    if (!user) return res.status(404).json({ error: 'Author not found' });

    const post = new Post({ title, content, author });
    await post.save();
    res.status(201).json(post);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get all posts (with optional author query)
router.get('/', async (req, res) => {
  try {
    const filter = {};
    if (req.query.author) {
      filter.author = req.query.author;
    }

    const posts = await Post.find(filter).populate('author', 'name email');
    res.json(posts);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get all posts by a specific user
router.get('/user/:id', async (req, res) => {
  try {
    const userId = req.params.id;

    const userExists = await User.findById(userId);
    if (!userExists) return res.status(404).json({ error: 'User not found' });

    const posts = await Post.find({ author: userId }).populate('author', 'name email');
    res.json(posts);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
