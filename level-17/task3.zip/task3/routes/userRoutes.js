const express = require('express');
const router = express.Router();
const User = require('../models/User');

router.post('/api/users', async (req, res) => {
    try {
        const { name, email, age } = req.body;

        if (!name || !email) {
            return res.status(400).json({ error: 'Name and email are required' });
        }

        if (age && age < 18) {
            return res.status(400).json({ error: 'Minimum age is 18' });
        }

        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ error: 'Email already exists' });
        }

        const newUser = new User({ name, email, age });
        const savedUser = await newUser.save();

        return res.status(201).json(savedUser);

    } catch (error) {
        console.error('Server error:', error);
        return res.status(500).json({ error: 'Server error' });
    }
});

module.exports = router;
